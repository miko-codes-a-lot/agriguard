package com.example.agriguard.modules

object AppModule {
}