package com.example.agriguard.modules.intro.splash

import androidx.compose.runtime.Composable

@Composable
fun SplashScreenUI () {
}