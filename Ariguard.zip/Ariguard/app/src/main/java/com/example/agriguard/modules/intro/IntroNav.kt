package com.example.agriguard.modules.intro

sealed class IntroNav(val route: String) {
    object Splash : IntroNav("splash")
    object LogIn : IntroNav("login")

}